This package includes the source codes for  "Novel Coplanar Line-points Invariants for Robust Line Matching Across Views". 

To run the program, please:

1.Run 'TestLMDll' with Microsoft Visual Studio 2010 to get lines detected by LSD and points matched by SIFT.

2.Put the images into directory 'img' , and put the files of matched points and detected lines into directory 'pts&lines'.
 
3.Run linematch (linematch.m) in MATLAB.

Some of the paths need to be changed.


