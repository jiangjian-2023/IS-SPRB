clear; clc; close all;
im1 = imread('D:\lunwen\����ָ��\ƴ��\����\3.jpg');
% a = im1(:,:,1);
% b = im1(:,:,2);
% c = im1(:,:,3);
% figure
% imshow(im1);
% 
% 
% for i = 1:size(a,1)
%     for j = 1:size(a,2)
%         if a(i,j)==255
%            im1(i,j,1) = 0;
%         end
%     end
% end
% for i = 1:size(b,1)
%     for j = 1:size(b,2)
%         if b(i,j)==255
%            im1(i,j,2) = 0;
%         end
%     end
% end
% for i = 1:size(c,1)
%     for j = 1:size(c,2)
%         if c(i,j)==255
%            im1(i,j,3) = 0;
%         end
%     end
% end
% figure
% imshow(im1);

im1_p = im1;
im2_p = im1;


mask1 = logical(im1_p);
mask2 = logical(im2_p);

mask_overlap = mask1 & mask2;


% figure;
 mask_overlap  = mask_overlap(:,:,1) & mask_overlap(:,:,2) & mask_overlap(:,:,3);
% % mask_overlap  = mask_overlap(:,:,1) | mask_overlap(:,:,2) | mask_overlap(:,:,3);
% imwrite(mask_overlap, ['D:\lunwen\����ָ��\ƴ��\����\','00002.jpg']);
%% 
boundaries = bwboundaries(mask_overlap);
boundary = boundaries{1};
mask = zeros(size(mask_overlap));

% ʹ�� poly2mask �������߽�����ת��Ϊһ����ģ
% bw = poly2mask(boundary(:, 1), boundary(:, 2), size(mask_overlap, 1), size(mask_overlap, 2));
bw = poly2mask(boundary(:, 2),boundary(:, 1), size(mask_overlap, 1), size(mask_overlap, 2));
% ����ģ�е�ֵ��Ϊ1
mask(bw) = 1;

% �� matrix �ж�Ӧ��ģΪ1��λ������Ϊ1
mask_overlap(mask == 1) = 1;
%% 
imshow(mask_overlap) ;
hold on ;
imwrite(mask_overlap, ['D:\lunwen\����ָ��\ƴ��\����\','00002.jpg']);
% maska = logical(im1);
% maskb = maska(:,:,1) |maska(:,:,2) |maska(:,:,3) ;
% figure
% imshow(maskb);
% % im1 = imread('D:\lunwen\DeepRectangling-main\DeepRectangling-main\Codes_for_Arbitrary_Resolution\other_dataset\mask\00011.jpg');
% a = im1(:,:,1);
% b = im1(:,:,2);
% c = im1(:,:,3);
% N = a|b|c;
% 
% 
% for i = 1:size(a,1)
%     for j = 1:size(a,2)
%         if a(i,j)~=0
%            a(i,j) = 255;
%         end
%     end
% end
% for i = 1:size(b,1)
%     for j = 1:size(b,2)
%         if b(i,j)~=0
%            b(i,j) = 255;
%         end
%     end
% end
% for i = 1:size(c,1)
%     for j = 1:size(c,2)
%         if c(i,j)~=0
%            c(i,j) = 255;
%         end
%     end
% end
% 
% A =  logical (a);
% B =  logical (b);
% C =  logical (c);
% 
% D = A&B&C;
% E = D+0;
% 
% figure
% imshow(E);
% hold on 
% imshow(b);
% hold on
% imshow(c);
    