im1_p = img2Homo;
im2_p = img1Homo;


mask1 = logical(im1_p);
mask2 = logical(im2_p);

mask_overlap = mask1 & mask2;
% mask_overlap = mask_overlap +0 ;

figure;
mask_overlap  = mask_overlap(:,:,1) | mask_overlap(:,:,2) | mask_overlap(:,:,3);

%% 
boundaries = bwboundaries(mask_overlap);
boundary = boundaries{1};
mask = zeros(size(mask_overlap));

% ʹ�� poly2mask �������߽�����ת��Ϊһ����ģ
% bw = poly2mask(boundary(:, 1), boundary(:, 2), size(mask_overlap, 1), size(mask_overlap, 2));
bw = poly2mask(boundary(:, 2),boundary(:, 1), size(mask_overlap, 1), size(mask_overlap, 2));
% ����ģ�е�ֵ��Ϊ1
mask(bw) = 1;

% �� matrix �ж�Ӧ��ģΪ1��λ������Ϊ1
mask_overlap(mask == 1) = 1;
%% 
imshow(mask_overlap) ;
hold on ;

boundaries = bwboundaries(mask_overlap);
boundary = boundaries{1};
[a,b,c]=maxInnerRectangle(mask_overlap);
plot(b(:,1),b(:,2),'or')
plot(c(:,1),c(:,2),'or')
% bounds = bounding_box(mask_overlap);
bounds = [b ,c];
if b(1,1)>c(1,1)
    zuo = c(1,1):b(1,1)
else
    zuo = b(1,1):c(1,1);
end
if b(1,2)>c(1,2)
    you = c(1,2):b(1,2)
else
    you = b(1,2):c(1,2);
end

im1_overlap = im1_p;
fugure 
imshow(im1_p);
im1_overlap(~mask_overlap) = 0;
im1_overlap = im1_overlap(you,zuo,:);
figure;
imshow(im1_overlap);
im2_overlap = mosaic1;
im2_overlap(~mask_overlap) = 0;
im2_overlap = im2_overlap(you,zuo,:);
figure;
imshow(im2_overlap);


SSIM = ssim(im2uint8(im1_overlap),im2uint8(im2_overlap));
disp(['SSIM = ',num2str(SSIM)]);

function [maxArea, topLeft, bottomRight] = maxInnerRectangle(matrix)
    % �ҵ�������ͼ�εı߽�
    boundaries = bwboundaries(matrix);
    boundary = boundaries{1};
    dian = [];
    for i = 1:4:size(boundary,1)
        dian = [dian ; boundary(i,:)];
    end
    boundary = [];
    boundary = dian;
    % ��ʼ��������Ϊ0
    maxArea = 0;
    topLeft = [0, 0];
    bottomRight = [0, 0];
    
    % �Ա߽��ϵ�ÿ������б���
    for i = 1:size(boundary, 1)
        for j = i:size(boundary, 1)
            % ����������ȷ���ľ��ε����
            a = boundary(j,2);
            b = boundary(i,2);
            c = boundary(j,1);
            d =  boundary(i,1);
            
       
            % �����������ڲ�����ͼ���ڲ���������ڵ�ǰ��������������������;���λ��
%             if all(all(matrix(boundary(i,2):boundary(j,2),boundary(i,1):boundary(j,1))))
            if a > b 
               f = boundary(i,2):boundary(j,2) ;
            else
               f = boundary(j,2):boundary(i,2) ;
            end
            if c > d
                g = boundary(i,1):boundary(j,1);
            else
                g = boundary(j,1):boundary(i,1);
            end
            e = matrix(g,f);
%             e = matrix(boundary(i,2):boundary(j,2),boundary(i,1):boundary(j,1));
%             if sum(e(:)) == abs(area)
            if all(e(:)==1)
                area = (abs(a - b) + 1) * (abs(c - d) + 1);
                if abs(area) > maxArea
%                     plot(boundary(j,2),boundary(j,1),'or')
%                     plot(boundary(i,2),boundary(i,1),'or')
                    maxArea = area;
                    topLeft = [boundary(i,2), boundary(i,1)];
                    bottomRight = [boundary(j,2), boundary(j,1)];
                end
            end
        end
    end
end

