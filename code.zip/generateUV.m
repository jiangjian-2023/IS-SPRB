function [ lines_vs, lines_us, lines_ue,point1,point2,bianjie1,point,bianjie_xian] = generateUV( img1, img2, init_H, theta, C1 ,C2 )
% function [ point, lines_ue1, lines_ue,point1,point2,bianjie] = generateUV( img1, img2, init_H, theta, C1 ,C2 )
% function [ lines_vs, lines_ue1, lines_ue,point1,point2,bianjie] = generateUV( img1, img2, init_H, theta, C1 ,C2 )
% given an orientation of img, rotate the original control vertices Mv
% obtain the orthogonal equidistant lines
% generating v-slope lines, u-slope lines, u-equal lines
% based on u sample points in non-overlapping region
multi = 2;
[M, N, ~] = size(img1);  % size of img
R = [cos(theta), -sin(theta); sin(theta), cos(theta)];  % rotation matrix
off_center = [(N+1)/2; (M+1)/2] - R*[(N+1)/2; (M+1)/2];  % offset of rotated center r.t. original center��ת��ͼ�����ĵ�ƫ��
%% roughly calculate the overlapping boundary to filter u-sample points
warp_pts1 = init_H*[1;1;1]; warp_pts1 = warp_pts1(1:2)./warp_pts1(3);
left_or_right = warp_pts1(1)<=1;  [sz1, sz2, ~] = size(img2);
if left_or_right  % left is target, line x=1 is boundary
    inv_pts1 = init_H\[1;-sz1;1];  inv_pts1 = inv_pts1(1:2)./inv_pts1(3);
    inv_pts2 = init_H\[1;2*sz1;1]; inv_pts2 = inv_pts2(1:2)./inv_pts2(3);
else  % right is target, line x=N is boundary
    inv_pts1 = init_H\[sz2;-sz1;1];  inv_pts1 = inv_pts1(1:2)./inv_pts1(3);
    inv_pts2 = init_H\[sz2;2*sz1;1]; inv_pts2 = inv_pts2(1:2)./inv_pts2(3);
end
x1 = inv_pts1(1);  y1 = inv_pts1(2);  x2 = inv_pts2(1);  y2 = inv_pts2(2);

%% generating mesh grid (C1*C2) to optimize warped control vertices
[X, Y] = meshgrid(linspace(2-N, 2*N-1, 3*multi*(C2+1)-2), linspace(2-M, 2*M-1, 3*multi*(C1+1)-2)); % mesh grid index
lines_vs = zeros(2*size(X,2), size(X,1));
k=1;
% rotated vertical line  slope-preserving
for j=1:size(X,2)
    tmp_Mv = [X(:,j)'; Y(:,j)'];  % each vertical line
    tmp_line = R*tmp_Mv + repmat(off_center, 1,length(tmp_Mv)); % rotated vertical line
    inner_ind = (tmp_line(1,:)>=1) & (tmp_line(1,:)<=N) & (tmp_line(2,:)>=1) & (tmp_line(2,:)<=M); % rotated vertical line lies in img
    lines_vs(2*k-1:2*k, 1:sum(inner_ind)) = tmp_line(:,inner_ind);  % useful rotated vertical line
    lines_vs(2*k-1:2*k, end) = sum(inner_ind);  % number of sample points on the line
    k=k+1;
end 
% rotated horizontal line slope-preserving
lines_us = zeros(2*size(X,1), size(X,2));
k=1;
for i=1:size(X,1)
    tmp_Mv = [X(i,:); Y(i,:)];  % each horizontal line
    tmp_line = R*tmp_Mv + repmat(off_center, 1,length(tmp_Mv)); % rotated horizontal line
    inner_ind = (tmp_line(1,:)>=1) & (tmp_line(1,:)<=N) & (tmp_line(2,:)>=1) & (tmp_line(2,:)<=M); % rotated horizontal line lies in img
    lines_us(2*k-1:2*k, 1:sum(inner_ind)) = tmp_line(:,inner_ind);  % useful rotated horizontal line
    lines_us(2*k-1:2*k, end) = sum(inner_ind);  % number of sample points on the line
    k=k+1;
end 

lines_vs(all(sum(lines_vs,2),2)==0,:)=[];  % delete all-zero rows
lines_vs(:,all(sum(lines_vs,1),1)==0)=[];  % delete all-zero columns
lines_us(all(sum(lines_us,2),2)==0,:)=[];  % delete all-zero rows
lines_us(:,all(sum(lines_us,1),1)==0)=[];  % delete all-zero columns

%% filter u sample points (omit points in the overlapping region)
newlines_u = zeros(size(lines_us));
newlines_w = zeros(size(lines_us));
for i=1:2:size(lines_us,1)-1
    num_u = lines_us(i,end);
    vec_prod = (x1-lines_us(i,1:num_u)).*(y2-lines_us(i+1,1:num_u))+(lines_us(i+1,1:num_u)-y1).*(x2-lines_us(i,1:num_u));
    left = vec_prod>0;  right = vec_prod<0; %left = vec_prod>0;  right = vec_prod<0;
    index_prod = (left_or_right & left) | ((~left_or_right) & right);  % find the sample points in the non-overlapping region
    newlines_u(i:i+1, 1:sum(index_prod)) = lines_us(i:i+1, index_prod);
    
    newlines_u(i:i+1, end) = sum(index_prod); % number of sample points
    b = sum(index_prod) ;
    for j = 1:size(index_prod,2)
        if index_prod(j)==0
            index_prod(j)= 1;
        else 
            index_prod(j)= 0;
        end
    end
     newlines_w(i:i+1, 1:(num_u-b)) = lines_us(i:i+1, index_prod);
     newlines_w(i:i+1, end) = sum(index_prod); % number of sample points
end
lines_ue = newlines_u;  % u sample points to preserve equidistant
lines_ue(all(sum(lines_ue,2),2)==0,:)=[];  % delete all-zero rows
lines_ue(:,all(sum(lines_ue,1),1)==0)=[];  % delete all-zero columns


lines_ue1 = newlines_w;  % u sample points to preserve equidistant
lines_ue1(all(sum(lines_ue1,2),2)==0,:)=[];  % delete all-zero rows
lines_ue1(:,all(sum(lines_ue1,1),1)==0)=[];  % delete all-zero columns

if isempty(lines_ue)
    for i=1:2:size(lines_us,1)-1
        num_u = lines_us(i,end);
        vec_prod = (x1-lines_us(i,1:num_u)).*(y2-lines_us(i+1,1:num_u))+(lines_us(i+1,1:num_u)-y1).*(x2-lines_us(i,1:num_u));
        left = vec_prod<0;  right = vec_prod>0; %left = vec_prod>0;  right = vec_prod<0;
        index_prod = (left_or_right & left) | ((~left_or_right) & right);  % find the sample points in the non-overlapping region
        newlines_u(i:i+1, 1:sum(index_prod)) = lines_us(i:i+1, index_prod);
        newlines_u(i:i+1, end) = sum(index_prod); % number of sample points
    end
    lines_ue = newlines_u;  % u sample points to preserve equidistant
    lines_ue(all(sum(lines_ue,2),2)==0,:)=[];  % delete all-zero rows
    lines_ue1(:,all(sum(lines_ue,1),1)==0)=[];  % delete all-zero columns
end      
% b= [];
% for i = 1:2:size(lines_ue1,1)
%     j = lines_ue1(i,end)
%     b =[b lines_ue1(i:i+1,j)];
% end
% point1 = b(:,1);
% c=[];
% for i = 1:2:size(lines_ue,1)
%     c =[c lines_ue(i:i+1,1)];
% end
% d = size(lines_ue,1)/2;
% point2 = c(:,d);     
% d1 = size(lines_ue,1);
% d2 = lines_us(d1,end);
% d3 = 0;
% for i = 1:d2
%    if  lines_us(d1,i) == point2(2,1)
%        d3 = i   
%    end
% end
% point2 =lines_us(d1-1:d1,d3-1) ;
c =[];
c1 = [];
for i = 1:2:size(lines_ue1,1)
    if lines_ue1(i,end) < lines_us(i,end)
        c = [c lines_us(i:i+1,lines_ue1(i,end)+1) ];
    end
end
c1 = c(1,:);
max1 =0;
min1=0;
max1 = max(c1)  ;
min1 = min(c1) ;
point1 = [];
point2 = [];



    


%%�ص����ֵĴ�ֱ
point_chong = [];
for i = 1:2:size(lines_ue1,1)
    for j = 1:lines_ue1(i,end)
        point_chong = [point_chong lines_ue1(i:i+1,j)] ;
    end
end
point = zeros(size(lines_vs,1),size(lines_vs,2));
for i = 1:size(point_chong,2)
   
    for j = 1:2:size(lines_vs,1)
        
        for k = 1:lines_vs(j,end)
            if point_chong(1,i)==lines_vs(j,k)
                point(j:j+1,k) = lines_vs(j:j+1,k);
                
            end
        end
        
    end
end

point(all(sum(point,2),2)==0,:)=[];  % delete all-zero rows

a = zeros(size(point,1),size(point,2));
for i = 1:2:size(point,1)
    a = find(point(i,:));
    point(i:i+1,end) = a(end);
    a =[];
end
num = 0;
for i = 1:2:size(point,1)
    num = num + point(i,end);
end
bb = [];
for i = 1:2:size(point,1)
    a = 0 ;
    for j = 1:point(i,end)
        if point(i,j) == 0 && point(i+1,j) == 0
            a = a+1;
        end
    end
    bb = [bb a a ];
end
point9 = zeros(size(point,1),size(point,2));
for i = 1:2:size(point,1)
    point9(i:i+1,1:end-bb(i)-1) = point(i:i+1,bb(i)+1:end-1)
    point9(i:i+1,end) =point(i,end)-bb(i);
end
    point = [];
    point = point9;
%ϸ���ص��߽�%%%%%%%%%
c =[];
c1 = [];
point3 = [];

for i = 1:2:size(lines_ue1,1)
    for j = 1:2:size(lines_us,1)
        if lines_ue1(i,1) == lines_us(j,1)
            if lines_ue1(i,end) < lines_us(j,end)
                point3 = [point3 lines_ue1(i:i+1,lines_ue1(i,end)) ];
            end
        end
    end
end

bianjie = zeros(size(point,1),size(point,1));

for i = 1:2:size(point,1)
    k=0;
    for j = 1:size(point3,2)
        if ismember(point3(1,j),point(i,:))
            k = k+1;
            bianjie(size(point,1)-i:size(point,1)-i+1,k) = point3(1:2,j);
            
        end
    end
    bianjie(size(point,1)-i:size(point,1)-i+1,end) = k;
    
end
bianjie(all(sum(bianjie,2),2)==0,:)=[];  % delete all-zero rows
bianjie(:,all(sum(bianjie,1),1)==0)=[];  % delete all-zero columns
xian = [];
for i = 1:2:size(bianjie,1)
    xian = [xian bianjie(i+1,1)];
end
[d xu] = sort(xian);
bianjie1 = zeros(size(bianjie,1),size(bianjie,2));
j=1;
e = [];
for i = 1:2:size(bianjie,1)
    
    bianjie1(i:i+1,:) = bianjie(2*xu(j)-1:2*xu(j),:);
    j=j+1;
    e = [e max(bianjie(i,1:end-1))];
end
% ȥ��������2������
for i= 1:2:size(bianjie,1)
    if  bianjie1(i,end) <2
        bianjie1(i:i+1,:) = 0;
    end
end
bianjie1(all(sum(bianjie1,2),2)==0,:)=[];  % delete all-zero rows
bianjie1(:,all(sum(bianjie1,1),1)==0)=[];  % delete all-zero columns
bianjie_xian = [];
for i=1:2:size(bianjie1,1)
    xian = [bianjie1(i:i+1,1) bianjie1(i:i+1,bianjie1(i,end))];
    bianjie_xian = [bianjie_xian;xian];
end
%
max1 = max(e);

point1 = [ max1 0];
point2 = [max1 size(img1,1)];
    
figure,imshow(img1);
hold on
% plot(lines_us(1:2:end-1,1:end-1), lines_us(2:2:end,1:end-1),'rx', 'LineWidth',2);  %���к���
% plot(point(1:2:end-1,1:end-1), point(2:2:end,1:end-1),'gx', 'LineWidth',2);  %�ص����������
%plot(point1(1,1),point1(2,1),'bx', 'LineWidth',2);
% plot(point2(1,1),point2(2,1),'bx', 'LineWidth',2);
%plot(lines_ue1(1:2:end-1,1:end-1), lines_ue1(2:2:end,1:end-1),'go', 'LineWidth',2);
% plot(lines_ue(1:2:end-1,1:end-1), lines_ue(2:2:end,1:end-1),'rx', 'LineWidth',2);
% % plot(point(1:2:end-1,1:end), point(2:2:end,1:end),'bx', 'LineWidth',2);
% % plot(bianjie1(1:2:end-1,1:end-1), bianjie1(2:2:end,1:end-1),'bo', 'LineWidth',2);
% for i = 1:2:size(bianjie_xian,1)
%     plot(bianjie_xian(i,1:2), bianjie_xian(i+1,1:2),'-bo', 'LineWidth',2);
% end
% hold off
% figure
% hold on
% 
%     plot(bianjie_xian(3,1:2), bianjie_xian(4,1:2),'-bo', 'LineWidth',2);
% 
% hold off



